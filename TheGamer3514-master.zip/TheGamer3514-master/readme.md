
<img src="/github-metrics.svg" alt="Metrics" width="400">

## 👋 About Me

- 🔭 I’m currently working on [Silly Development](https://discord.gg/sillydev).
- 🌱 I’m learning **Python**, **PHP**, **Javascript**, and many more.

## 📫 Connect with Me!

<a href="https://discord.com/channels/@me/763471049894527006">
  <img src="https://discord.c99.nl/widget/theme-2/763471049894527006.png" alt="Discord" />
</a>

- [Discord Server](https://discord.gg/sillydev) 💬

## 📊 GitHub Stats!

<p>
  <img src="https://github-readme-stats.vercel.app/api/top-langs?username=thegamer3514&show_icons=true&locale=en&layout=compact&theme=radical" alt="Top Languages" />
</p>
<p>
  <img src="https://github-readme-stats.vercel.app/api?username=thegamer3514&show_icons=true&locale=en&theme=radical" alt="GitHub Stats" />
</p>
<a href="https://git.io/streak-stats"><img src="https://streak-stats.demolab.com?user=TheGamer3514&theme=radical&hide_border=true&date_format=j%20M%5B%20Y%5D" alt="GitHub Streak" /></a>
<img src="https://raw.githubusercontent.com/TheGamer3514/TheGamer3514/output/snake.svg" alt="Snake animation" />
