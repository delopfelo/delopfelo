export { world, system, EquipmentSlot, BlockPermutation, ItemStack, MolangVariableMap} from "@minecraft/server";



