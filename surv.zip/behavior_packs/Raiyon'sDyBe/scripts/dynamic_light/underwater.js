export const underWater = [
    "end_rod",
    "breeze_rod",
    "minecraft:magma",
    "ray:sea_torch",
    "shroomlight",
    "froglight",
    "blaze",
    "lantern",
    "glowstone",
    "beacon",
    "lit_pumpkin",
    "sea_pickle",
];
