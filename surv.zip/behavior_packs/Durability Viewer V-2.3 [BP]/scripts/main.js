import { EntityComponentTypes, EquipmentSlot, ItemComponentTypes, system, world } from "@minecraft/server"

const helmet = {
  "minecraft:turtle_helmet": "ht",
  "minecraft:leather_helmet": "hl",
  "minecraft:copper_helmet": "ho",
  "minecraft:chainmail_helmet": "hc",
  "minecraft:iron_helmet": "hi",
  "minecraft:golden_helmet": "hg",
  "minecraft:diamond_helmet": "hd",
  "minecraft:netherite_helmet": "hn",

  "generic": "gh",
  "undefined": "he"
},

chestplate = {
  "minecraft:leather_chestplate": "cl",
  "minecraft:copper_chestplate": "co",
  "minecraft:chainmail_chestplate": "cc",
  "minecraft:iron_chestplate": "ci",
  "minecraft:elytra": "el",
  "minecraft:golden_chestplate": "cg",
  "minecraft:diamond_chestplate": "cd",
  "minecraft:netherite_chestplate": "cn",

  "generic": "gc",
  "undefined": "ce"
},

leggings = {
  "minecraft:leather_leggings": "ll",
  "minecraft:copper_leggings": "lo",
  "minecraft:chainmail_leggings": "lc",
  "minecraft:iron_leggings": "li",
  "minecraft:golden_leggings": "lg",
  "minecraft:diamond_leggings": "ld",
  "minecraft:netherite_leggings": "ln",

  "generic": "gl",
  "undefined": "le"
},

boots = {
  "minecraft:leather_boots": "bl",
  "minecraft:copper_boots": "bo",
  "minecraft:chainmail_boots": "bc",
  "minecraft:iron_boots": "bi",
  "minecraft:golden_boots": "bg",
  "minecraft:diamond_boots": "bd",
  "minecraft:netherite_boots": "bn",

  "generic": "gb",
  "undefined": "be"
}

let runID;
let armor, shield;

world.afterEvents.playerSpawn.subscribe(event => {
  const player = event.player;

  player.onScreenDisplay.setTitle(armorDurability(player), {
    stayDuration: 100,
    fadeInDuration: 2,
    fadeOutDuration: 4,
    subtitle: shieldDurability(player)
  });

  runID = system.runInterval(() => {
    durabilityFunction(player);
  }, 5);
});

world.afterEvents.playerLeave.subscribe((event) => {
  system.clearRun(runID);
});

function durabilityFunction(player) {
  const armor_n = armorDurability(player);
  const shield_n = shieldDurability(player);

  if (armor_n != armor || shield_n != shield) {
    player.onScreenDisplay.setTitle(armor_n, {
      stayDuration: 100,
      fadeInDuration: 2,
      fadeOutDuration: 4,
      subtitle: shield_n
    });

    armor = armor_n;
    shield = shield_n;
  }
}

function shieldDurability(player) {  
  const equippable = player.getComponent(EntityComponentTypes.Equippable),
    offhandItem = equippable?.getEquipment(EquipmentSlot.Offhand),
    offhandItemDurability = offhandItem?.getComponent(ItemComponentTypes.Durability),
    offhandItemDurabilityText = offhandItemDurability?.maxDurability === undefined ? 'No Shield' : `Shield: ${offhandItemDurability.maxDurability - offhandItemDurability.damage}/${offhandItemDurability.maxDurability}`;

  return `durabilityShield:${offhandItemDurabilityText}`;
}

function armorDurability(player) {
  const equippable = player.getComponent(EntityComponentTypes.Equippable),
    headItem = equippable?.getEquipment(EquipmentSlot.Head),
    chestItem = equippable?.getEquipment(EquipmentSlot.Chest),
    legItem = equippable?.getEquipment(EquipmentSlot.Legs),
    feetItem = equippable?.getEquipment(EquipmentSlot.Feet),

    headItemDurability = headItem?.getComponent(ItemComponentTypes.Durability),
    chestItemDurability = chestItem?.getComponent(ItemComponentTypes.Durability),
    legItemDurability = legItem?.getComponent(ItemComponentTypes.Durability),
    feetItemDurability = feetItem?.getComponent(ItemComponentTypes.Durability),

    headItemDurabilityText = headItemDurability?.maxDurability === undefined ? '' : ` ${headItemDurability.maxDurability - headItemDurability.damage}/${headItemDurability.maxDurability}`,
    chestItemDurabilityText = chestItemDurability?.maxDurability === undefined ? '' : ` ${chestItemDurability.maxDurability - chestItemDurability.damage}/${chestItemDurability.maxDurability}`,
    legItemDurabilityText = legItemDurability?.maxDurability === undefined ? '' : ` ${legItemDurability.maxDurability - legItemDurability.damage}/${legItemDurability.maxDurability}`,
    feetItemDurabilityText = feetItemDurability?.maxDurability === undefined ? '' : ` ${feetItemDurability.maxDurability - feetItemDurability.damage}/${feetItemDurability.maxDurability}`,

    headItemName = helmet[headItem?.typeId] ?? helmet.generic,
    chestItemName = chestplate[chestItem?.typeId] ?? chestplate.generic,
    legItemName = leggings[legItem?.typeId] ?? leggings.generic,
    feetItemName = boots[feetItem?.typeId] ?? boots.generic;

  return `durabilityArmor:${headItemName}${chestItemName}${legItemName}${feetItemName}§z${headItemDurabilityText}\n${chestItemDurabilityText}\n${legItemDurabilityText}\n${feetItemDurabilityText}`;
}